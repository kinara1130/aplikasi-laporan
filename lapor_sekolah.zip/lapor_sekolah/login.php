<?php

header("Content-Type: application/json");

include "koneksi.php";

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if ($username == '' || $password == '') {
    echo json_encode([
        "status" => false,
        "message" => "Username dan password wajib diisi"
    ]);
    exit;
}

$query = mysqli_query(
    $conn,
    "SELECT * FROM users 
     WHERE username='$username' 
     AND password='$password'"
);

if (mysqli_num_rows($query) > 0) {

    $data = mysqli_fetch_assoc($query);

    echo json_encode([
        "status" => true,
        "message" => "Login berhasil",
        "data" => [
            "id" => $data['id'],
            "username" => $data['username'],
            "nama" => $data['nama'],
            "role" => $data['role']
        ]
    ]);

} else {

    echo json_encode([
        "status" => false,
        "message" => "Username atau password salah"
    ]);
}

?>